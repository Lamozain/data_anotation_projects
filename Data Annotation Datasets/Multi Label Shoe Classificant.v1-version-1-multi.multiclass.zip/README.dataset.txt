# Multi Label Shoe Classificant > Version 1 Multi
https://universe.roboflow.com/amoslacon/multi-label-shoe-classificant-vtgx1

Provided by a Roboflow user
License: CC BY 4.0

