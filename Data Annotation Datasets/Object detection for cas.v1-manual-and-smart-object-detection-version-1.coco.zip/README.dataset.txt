# Object detection for cas > Manual and Smart Object Detection Version 1
https://universe.roboflow.com/amoslacon/object-detection-for-cas-bmico

Provided by a Roboflow user
License: CC BY 4.0

