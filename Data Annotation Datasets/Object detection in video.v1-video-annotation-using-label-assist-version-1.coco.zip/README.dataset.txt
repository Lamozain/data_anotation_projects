# Object detection in video > Video annotation using label assist Version 1
https://universe.roboflow.com/amoslacon/object-detection-in-video-0shp9

Provided by a Roboflow user
License: CC BY 4.0

