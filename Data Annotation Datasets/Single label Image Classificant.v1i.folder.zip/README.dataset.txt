# Single label Image Classificant > 2025-08-07 12:16pm
https://universe.roboflow.com/amoslacon/single-label-image-classificant-u1i3f

Provided by a Roboflow user
License: CC BY 4.0

